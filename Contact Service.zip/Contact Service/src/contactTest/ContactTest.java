package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {

	// Testing class
	@Test
	void testContact() {
		Contact contact = new Contact("0000000001", "Lee", "Anthony", "0123456789", "123 Example St.");
		assertTrue(contact.getContactID().equals("0000000001"));
		assertTrue(contact.getLastName().equals("Lee"));
		assertTrue(contact.getFirstName().equals("Anthony"));
		assertTrue(contact.getPhone().equals("0123456789"));
		assertTrue(contact.getAddress().equals("123 Example St."));
	}
	
	// Testing Contact ID length
	@Test
	void testContactContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("00000000001", "Lee", "Anthony", "0123456789", "123 Example St.");
		});		}
	
	// Testing Contact ID for null
	@Test
	void testContactContactIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Lee", "Anthony", "0123456789", "123 Example St.");
		});		}
	
	
	// Testing Last Name length
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee012345678", "Anthony", "0123456789", "123 Example St.");
		});		}
	
	// Testing Last Name for null
	@Test
	void testContactLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", null, "Anthony", "0123456789", "123 Example St.");
		});		}
	
	
	// Testing First Name length
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony01234", "0123456789", "123 Example St.");
		});		}
	
	// Testing First Name for null
	@Test
	void testContactFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", null, "0123456789", "123 Example St.");
		});		}
	
	// Testing Phone for length
	@Test
	void testContactPhoneIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony", "01234567890", "123 Example St.");
		});		}
	
	// Testing Phone for length
	@Test
	void testContactPhoneIsTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony", "012345678", "123 Example St.");
		});		}
	
	// Testing Phone for null
	@Test
	void testContactPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony", null, "123 Example St.");
		});		}
	
	// Testing Address for Length
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony", "0123456789", "123 Example St. 0123456789101112");
		});		}
	
	// Testing Address for null
	@Test
	void testContactAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0000000001", "Lee", "Anthony", "0123456789", null);
		});		}
}
